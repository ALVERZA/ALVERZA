 "use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import { Search, ShoppingCart, UserRound, Store, Globe2 } from "lucide-react";

const products = [
 {id:1,name:"Bluetooth qulaqlıq",price:25,cat:"Elektronika",seller:"TechPoint",img:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=700&q=80"},
 {id:2,name:"Minimal masa lampası",price:38,cat:"Ev və bağ",seller:"HomeLine",img:"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=700&q=80"},
 {id:3,name:"Gündəlik bel çantası",price:42,cat:"Geyim",seller:"Urban Shop",img:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=700&q=80"},
 {id:4,name:"Mətbəx aksesuar dəsti",price:29,cat:"Ev və bağ",seller:"Mətbəxim",img:"https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=700&q=80"},
 {id:5,name:"Ağıllı saat",price:79,cat:"Elektronika",seller:"TechPoint",img:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=700&q=80"},
 {id:6,name:"İdman ayaqqabısı",price:65,cat:"Geyim",seller:"Urban Shop",img:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=80"},
 {id:7,name:"Dəri pulqabı",price:32,cat:"Aksesuar",seller:"ModaPlus",img:"https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=700&q=80"},
 {id:8,name:"Su qabı",price:14,cat:"İdman",seller:"FitStore",img:"https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=700&q=80"}
];
const categories = [{name:"Hamısı",icon:"🛍️"},{name:"Elektronika",icon:"📱"},{name:"Geyim",icon:"👕"},{name:"Ev və bağ",icon:"🏠"},{name:"Aksesuar",icon:"🎒"},{name:"İdman",icon:"⚽"}];
export default function Home(){
 const [q,setQ]=useState(""); const [cat,setCat]=useState("Hamısı"); const [cart,setCart]=useState<number[]>([]); const [lang,setLang]=useState("AZ");
 const visible=useMemo(()=>products.filter(p=>(cat==="Hamısı"||p.cat===cat)&&p.name.toLowerCase().includes(q.toLowerCase())),[q,cat]);
 return <><div className="top"><span>Azərbaycanda onlayn alış-verişin yeni ünvanı</span><span>Çatdırılma şərtləri · Dəstək</span></div>
 <header className="header"><div className="wrap"><div className="headrow"><Link className="logo" href="/">ALVER<b>ZA</b></Link><div className="search"><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Məhsul, brend və ya mağaza axtar..." /><button aria-label="Axtar"><Search size={18}/></button></div><div className="headactions"><span onClick={()=>setLang(lang==="AZ"?"RU":lang==="RU"?"EN":"AZ")} style={{cursor:"pointer"}}><Globe2 size={16}/> {lang}</span><Link href="/seller"><Store size={17}/> Satıcı ol</Link><Link href="/cart"><ShoppingCart size={17}/> Səbət ({cart.length})</Link></div></div><nav className="nav"><Link href="/">Ana səhifə</Link><Link href="/seller">Satıcı kabineti</Link><Link href="/cart">Səbət</Link><a href="#categories">Kateqoriyalar</a><a href="#products">Məhsullar</a></nav></div></header>
 <main className="wrap"><section className="hero"><div><span className="pill">ALVERZA MARKETPLACE</span><h1>Sevdiyin hər şey, bir platformada.</h1><p>Fərqli mağazalardan minlərlə məhsulu kəşf et və rahat sifariş ver.</p><a className="primary" href="#products">Alış-verişə başla</a></div><div className="heroart">🛍️</div></section>
 <div className="sectionhead" id="categories"><h2>Kateqoriyalar</h2><span className="muted">Sənə uyğun olanı seç</span></div><div className="cats">{categories.map(c=><button key={c.name} className="cat" onClick={()=>setCat(c.name)} style={{outline:cat===c.name?"2px solid #ff7a1a":"none"}}><span>{c.icon}</span>{c.name}</button>)}</div>
 <div className="sectionhead" id="products"><h2>Seçilmiş məhsullar</h2><span className="muted">{visible.length} məhsul</span></div><div className="products">{visible.map(p=><article className="product" key={p.id}><img src={p.img} alt={p.name}/><div className="pbody"><div className="pname">{p.name}</div><div className="price">{p.price.toFixed(2)} AZN</div><div className="seller">Satıcı: {p.seller}</div><button className="add" onClick={()=>setCart([...cart,p.id])}>Səbətə əlavə et</button></div></article>)}</div>
 <div className="panel"><h2>ALVERZA-da satıcı ol</h2><p className="muted">Mağazanı yarat, məhsullarını yerləşdir və yeni müştərilərə çat.</p><Link className="primary" href="/seller">Satıcı qeydiyyatı</Link></div></main>
 <footer className="footer"><div className="wrap footergrid"><div><div className="logo" style={{color:"white"}}>ALVER<b>ZA</b></div><p>Bir platforma. Minlərlə məhsul. Rahat alış-veriş.</p></div><div><b>Müştərilər üçün</b><p>Çatdırılma</p><p>Qaytarılma</p><p>Dəstək</p></div><div><b>Satıcılar üçün</b><p><Link href="/seller">Satıcı kabineti</Link></p><p>Qaydalar</p><p>Komissiyalar</p></div></div></footer></>;
}